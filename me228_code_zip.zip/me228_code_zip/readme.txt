This folder has 4 directories:

1. Fluid: It contains code file (fluid_wake.ipynb); dataset (fluid.csv) and trained model weights (fluid_wake.pt)
2. Lorenz: It has code file for regression fit (SINDy.ipynb); code file for PINN (lorenz.ipynb); dataset (Lorenz.csv) and trained model weights (lorenz.pt)
3. Pendulum: It has 4 code files (DataGeneration.ipynb, FinalClasses.ipynb, FullNetwork.ipynb, FunctionalAutoencoder.ipynb)
4. RBD: It has code file (rbd.ipynb); dataset (RBD.csv) and trained model weights (rbd.pt)
